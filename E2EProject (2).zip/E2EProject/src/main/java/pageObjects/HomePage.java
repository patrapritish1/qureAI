package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

	private WebElement signup;
	
	private WebElement login;
	
	private WebElement newArticle;
	
	private WebDriver driver;
	
	public HomePage(WebDriver driver){
		
		this.driver = driver;
		signup = driver.findElement(By.cssSelector("[href*='register']"));
		login = driver.findElement(By.cssSelector("[href*='login']"));
		newArticle = driver.findElement(By.cssSelector("[href*='editor']"));
		
		
	}
	
	public WebElement signupHypLnk() {
		return signup;
	}
	
	public WebElement loginHypLnk() {
		return login;
	}
	
	public WebElement newArticleHypLnk() {
		return newArticle;
	}
	
	public WebElement globalFeedLnk() {
		return driver.findElement(By.xpath("//a[contains(text(),'Global Feed')]"));
	}
	
	public WebElement myArticle() {
		return driver.findElement(By.xpath("(//div[@class='article-preview'])[1]"));
	}
}
