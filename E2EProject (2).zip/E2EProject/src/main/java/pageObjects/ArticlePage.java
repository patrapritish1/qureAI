package pageObjects;

import java.time.LocalDateTime;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import junit.framework.Assert;

public class ArticlePage {

	private WebElement articleTitle;
	private WebElement articleAbout;
	private WebElement articleBody;
	private WebElement tags;
	private WebElement publishArticleBtn;
	private WebDriver driver;
	private String articleNewBody;
	private String comment;
	static Logger log;
	
	public ArticlePage(WebDriver driver){
	
	this.driver = driver;
	
	articleTitle = driver.findElement(By.xpath("(//*[@type='text'])[1]"));
	
	articleAbout = driver.findElement(By.xpath("(//*[@type='text'])[2]"));
	
	articleBody = driver.findElement(By.xpath("//textarea"));
	
	tags =  driver.findElement(By.xpath("(//*[@type='text'])[3]"));
	
	publishArticleBtn = driver.findElement(By.xpath("//button[contains(text(),'Publish Article')]"));
	
	}
	
	public ArticlePage(WebDriver driver2, String articleNewBody, String comment, Logger log) throws InterruptedException {
		this.driver = driver2;
		this.articleNewBody = articleNewBody;
		this.comment = comment;
		this.log = log;
		Assert.assertTrue(this.editArticle(articleNewBody));
		
		log.info("Edited post successfully");
		
		Assert.assertTrue(this.addComment(comment));
		
		log.info("comment added successfully");
		
		
	}

	public WebElement enterArticleInfo(String articleTitle, String articleAbout, String articleBody, String tags) {
		
		this.articleTitle.sendKeys(articleTitle);
		this.articleAbout.sendKeys(articleAbout);
		this.articleBody.sendKeys(articleBody);
		this.tags.sendKeys(tags);
		
		return publishArticleBtn;
	}
	
	public boolean editArticle(String articleNewBody) throws InterruptedException {
	
		String articleHeader = driver.findElement(By.tagName("h1")).getText();
		
		driver.findElement(By.xpath("//i[@class='ion-edit']")).click();
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//textarea")).sendKeys(articleNewBody);
		
		driver.findElement(By.xpath("//button[contains(text(),'Publish Article')]")).click();
		
		Thread.sleep(5000);
		
		return driver.findElement(By.xpath("//h1[contains(text(),'"+articleHeader+"')]")).isDisplayed();
			
	}
	
	public boolean addComment(String comment) throws InterruptedException {
		
	
		driver.findElement(By.xpath("//textarea")).sendKeys(comment);
		
		Thread.sleep(5000);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)", "");
		
		driver.findElement(By.xpath("//button[contains(text(),'Post Comment')]")).click();
		
		Thread.sleep(5000);
		
		return driver.findElement(By.xpath("//div[@class='card-block']//p[contains(text(),'"+comment+"')]")).isDisplayed();
		
			
	}
	
	public void favoriteAndFollow() throws InterruptedException{
		
		driver.findElement(By.xpath("(//a[contains(text(),'Home')])[2]")).click();
		
		driver.findElement(By.xpath("//a[contains(text(),'Global Feed')]")).click();
		
		driver.findElement(By.xpath("(//div[@class='article-preview'])[2]")).click();
		
		driver.findElement(By.xpath("//span[contains(text(),'Favorite Article')]")).click();
		
		Thread.sleep(3000);
		
		Assert.assertTrue(driver.findElement(By.xpath("//span[contains(text(),'Unfavorite Article')]")).isDisplayed());
		
		
		driver.findElement(By.xpath("//i[@class='ion-plus-round']")).click();
		
		Thread.sleep(3000);
		
		Assert.assertTrue(driver.findElement(By.xpath("//button[contains(@class,'btn btn-sm action-btn ng-binding btn-secondary')]")).isDisplayed());
			
				
		// for logging out
		
		driver.findElement(By.cssSelector("[href*='settings']")).click();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)", "");
	}
	
}