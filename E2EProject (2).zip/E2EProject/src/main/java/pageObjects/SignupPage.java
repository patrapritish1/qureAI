package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SignupPage {

	private WebElement uname;
	
	private WebElement email;
	
	private WebElement pwd;
	
	private WebElement signupBtn;
	
		
	public SignupPage(WebDriver driver){
		
		
		
		uname = driver.findElement(By.cssSelector("[placeholder='Username']"));

		email = driver.findElement(By.cssSelector("[placeholder='Email']"));
		
		pwd = driver.findElement(By.cssSelector("[placeholder='Password']"));
		
		signupBtn = driver.findElement(By.xpath("//button[contains(text(),'Sign up')]"));
		
		
	}
	
	public WebElement enterSignupDetails(String uname, String pwd) {
		
		this.uname.sendKeys(uname);
		
		this.email.sendKeys(uname+"@gmail.com");
		
		this.pwd.sendKeys(pwd);
		
		return signupBtn;
	}
	
}
