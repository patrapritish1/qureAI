package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	private WebElement email;
	
	private WebElement pwd;
	
	private WebElement signinBtn;
	
	public LoginPage(WebDriver driver) {
		
		email = driver.findElement(By.cssSelector("[type='email']"));
		
		pwd = driver.findElement(By.cssSelector("[type='password']"));
		
		signinBtn = driver.findElement(By.xpath("//button[contains(text(),'Sign in')]"));
		
	}
	
	public WebElement enterLoginDetails(String email, String pwd) {
		
		this.email.sendKeys(email);
		
		this.pwd.sendKeys(pwd);
		
		return signinBtn;
		
	}
	
	
}
