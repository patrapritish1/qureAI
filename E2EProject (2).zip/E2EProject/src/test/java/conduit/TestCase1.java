package conduit;

import java.io.IOException;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import junit.framework.Assert;
import pageObjects.ArticlePage;
import pageObjects.HomePage;
import pageObjects.SignupPage;
import resources.base;

public class TestCase1 extends base{
	
	
	public WebDriver driver;
	static Logger log = LogManager.getLogger();
	
	@BeforeTest
	public void driverUrl() throws IOException {
		driver = initializeDriver();
		driver.get(prop.getProperty("url"));
	}
	
	@Test
	public void tcOne() throws IOException, InterruptedException {
		
		//For signing up & posting article (covers stories 1 & 3)
		
		HomePage hp = new HomePage(driver);
		
		hp.signupHypLnk().click(); // clicking on signup hyperlink
			
		Random rand = new Random();
		
		String uname = "abc"+Math.abs(rand.nextInt());
		
		String pwd = "naradMuni@108";
		
		SignupPage sp = new SignupPage(driver);
		
		sp.enterSignupDetails(uname, pwd).click(); // enter registration details and click on signup
		
		Assert.assertTrue(driver.findElement(By.cssSelector("[href*='"+uname+"']")).isDisplayed()); // to check whether username is displayed after signing up
		
		log.info("Sign Up successful");
		
		hp.newArticleHypLnk().click(); // click on NewArticle for creating new article
		
		String articleTitle = "Hare Krishna"+uname;	
		
		ArticlePage ap = new ArticlePage(driver);
		
		ap.enterArticleInfo(articleTitle, "Krishna", "HKHKKKHHHRHRRRHH", "Krishna").click(); // entering article details and clicking pn publish article to post
			
		Thread.sleep(5000);
		
		Assert.assertTrue(driver.findElement(By.xpath("//h1[contains(text(),'"+articleTitle+"')]")).isDisplayed());
		
		log.info("Post successfully created");
		
	}
	
	@AfterTest
	public void endSession() {
		driver.close();
	}
	
}
