package conduit;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import junit.framework.Assert;
import pageObjects.ArticlePage;
import pageObjects.HomePage;
import pageObjects.LoginPage;
import resources.base;

public class TestCase2 extends base{

	public WebDriver driver;
	static Logger log = LogManager.getLogger();
	
	@BeforeTest
	public void driverUrl() throws IOException {
		driver = initializeDriver();
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
	}
	
	@Test
	public void tcTwo() throws IOException, InterruptedException {
		
		
		//For signing in, filtering global feed commenting/editing/liking article, following authors and signing out (covers user stories 2,4,5)
		
		HomePage hp = new HomePage(driver);
		
		hp.loginHypLnk().click(); // clicking on login hyperlink
		
		String email = "patrapritish1@gmail.com";
		
		String uname = email.split("@")[0];
		
		String pwd = "naradMuni@108";
		
		LoginPage lp = new LoginPage(driver);
		
		lp.enterLoginDetails(email, pwd).click(); // entering login details and clicking on signin btn
					
		Assert.assertTrue(driver.findElement(By.cssSelector("[href*='"+uname+"']")).isDisplayed());
		
		log.info("Succesfully logged in as "+uname);
		
		hp.globalFeedLnk().click(); // for filtering global feed
		
		Thread.sleep(3000);
		
		hp.myArticle().click(); // for clicking on user written article for editing
		
		String articleNewBody = "\nHKHKKKHHHRHRRRHH";
		
		String comment = "hk"+LocalDateTime.now();
		
		ArticlePage ap = new ArticlePage(driver, articleNewBody, comment,log);
		
				
		ap.favoriteAndFollow();
		
		log.info("Marked as favorite article and followed author");
		
		driver.findElement(By.xpath("//button[contains(text(),'logout')]")).click();
	
		if(driver.findElements(By.cssSelector("[href*='"+uname+"']")).isEmpty()) { //for logging out
			Assert.assertTrue(true);
			
			log.info("Succesfully logged out");
		}
			
		
	}
	
	@AfterTest
	public void endSession() {
		driver.close();
	}
}
